#include "Game.h"
#include <QApplication>
#include <QGraphicsScene>
#include "Cowboy.h"
#include <QGraphicsView>
#include <QTimer>
#include <QObject>
#include <QDebug>
#include <QFont>
#include <QGraphicsTextItem>
#include <QMediaPlayer>
#include <QGraphicsPixmapItem>
#include <QBrush>
#include <QImage>






Game::Game(QWidget *parent)
{

//variables
    ceilling = 240;


    //here I creat the elements that will appears on the scene



    //create a scene

    QGraphicsScene * scene = new QGraphicsScene();
    //size of the scene
    scene->setSceneRect(0,0,1200,700);
    //Background image

    scene->setBackgroundBrush(QBrush(QImage(":/img/Landscape_desert.jpg")));


    //Create an item that we put into the scene

    cowboy = new Cowboy();
  // cowboy->setRect(0,0,100,100);
    QPixmap image(":/img/cowboy.png");
    QPixmap imageHorse(":/img/horse.png");
    //we add the item to the scene
    cowboy->setPixmap(image);

    if(cowboy->getOwnHorse()==true){
         cowboy->setPixmap(imageHorse);
    }

    scene->addItem(cowboy);



    //make the item focusable

    cowboy->setFlag(QGraphicsItem::ItemIsFocusable);
    cowboy->setFocus();

    //we add the view

    QGraphicsView * view = new QGraphicsView(scene);
    view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    //show the view

    view->show();
    view->setFixedSize(1200,700);
    view->setWindowTitle("The C++ Town");

    cowboy->setPos(550,500);

    //create the score
    score = new Score();
    score->setPos(score->x()+400 , score->y());
    scene->addItem(score);

    //create the health
     health = new Health();
     health->setPos(health->x() , health->y()+25);
     scene->addItem(health);

     // add the women saved counter
     counter = new Freewomencounter;
     counter->setPos(counter->x(), counter->y()+50);
     scene->addItem(counter);

     // add the free bandits saved counter
     counterBandits = new Freebrigands;
     counterBandits->setPos(counterBandits->x(), counterBandits->y()+75);
     scene->addItem(counterBandits);

     //put the wall on the scene
     wall = new Wall1();
     scene->addItem(wall);

     //add the jail
     jail = new Building();
     scene->addItem(jail);


    //Spawn brigands
     QTimer * timerBrigand = new QTimer();
     QObject ::connect(timerBrigand,SIGNAL(timeout()),cowboy,SLOT(spawn()));
    timerBrigand->start(4000);

    //spawn the women
    QTimer * timerDame = new QTimer();
    QObject ::connect(timerDame,SIGNAL(timeout()),cowboy,SLOT(spawnDame()));
    dame = new Dame();
    timerDame->start(7000);


    //spawn the hedgehog
    QTimer * timerHedgehog = new QTimer();
    QObject ::connect(timerHedgehog,SIGNAL(timeout()),cowboy,SLOT(spawnHedgehog()));
    hed = new Hedgehog();
    timerHedgehog->start(10000);


//create the horse only if the cowboy doesn't have one yet

    QTimer * timerHorse = new QTimer();
    QObject ::connect(timerHorse,SIGNAL(timeout()),cowboy,SLOT(spawnHorse()));
    horse = new Horse();
    timerHorse->start(30000);



    //play background music
    QMediaPlayer * music = new QMediaPlayer();
    music->setMedia(QUrl("qrc:/sound/bg.mp3"));
    music->play();


}

int Game::getCeilling()
{
    return ceilling;
}
