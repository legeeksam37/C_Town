#include "Building.h"


Building::Building(QGraphicsItem *parent):QGraphicsPixmapItem(parent)
{
    setPixmap(QPixmap(":/img/building.png"));
    setPos(170,210);
}
