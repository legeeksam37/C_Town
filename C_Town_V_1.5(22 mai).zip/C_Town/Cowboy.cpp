#include "Cowboy.h"
#include <QKeyEvent>
#include "Balle.h"
#include <QGraphicsScene>
#include <QDebug>
#include "Brigand.h"
#include <QMediaPlayer>
#include "Dame.h"
#include "Hedgehog.h"
#include "Horse.h"
#include "Score.h"
#include <string>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <QString>
#include "Game.h"
#include "Wall1.h"
#include <QList>


// if( pos.y() > 400 && pos.y() < 500


extern Game * game;

Cowboy::Cowboy(QGraphicsItem *parent) :QGraphicsPixmapItem(parent)
{
    ownHorse = false;
    vitesse = 15;
    QString url;
    bool collideWall = true;



    if(this->ownHorse == false){
      url = ":/img/cowboy.png";
   }else if(this->ownHorse == true){
        url  =":/img/horse.png";
        emit SIGNAL(valueChanged(url));
   }

   /* if(ownHorse == false){
        vitesse = 10;
   }else if(ownHorse == true){
        vitesse = 50;

    }*/

        // setPixmap(QPixmap(url));



      //  setPixmap(QPixmap(":/img/horse.png"));


    bulletsound= new QMediaPlayer();
    bulletsound->setMedia(QUrl("qrc:/sound/bullet.mp3"));


}

void Cowboy::keyPressEvent(QKeyEvent *event)
{

        X_Prev = pos().x();
        Y_Prev = pos().y();

Wall1 * wall;





    //&& !collidesWithItem(Wall1)

    if(event->key() == Qt::Key_Left){
        //si la position ne dépasse pas le bord
        if(pos().x()>0)
         setPos(x()-vitesse,y());
        }


    if(event->key() == Qt::Key_Right){
        //si la position plus la taille du carée ne dépasse pas la largeur de la fenêtre
        if(pos().x()+100 < 1200)
        setPos(x()+vitesse,y());
    } if(event->key() == Qt::Key_Up /*&& !(typeid(*(colliding_cb[i]))== typeid(Wall1))*/ ){
            if(pos().y()> 0 && pos().y()>game->getCeilling())
             setPos(x(),y()-vitesse);
    } if(event->key() == Qt::Key_Down){
        if(pos().y()+100 < 700)
        setPos(x(),y()+vitesse);
    } if(event->key() == Qt::Key_Space){
        //on créer une balle quand on appuie sur espace
        Balle * balle = new Balle();
        //position de la balle sur la scene
        balle->setPos(x()+50,y()+42);
        scene()->addItem(balle);

       // Play the sound of the balle
        if(bulletsound->state()==QMediaPlayer::PlayingState){
            bulletsound->setPosition(0);
        }else if(bulletsound->state()==QMediaPlayer::StoppedState)
            bulletsound->play();
    }




    QList<QGraphicsItem *> colliding_cb = collidingItems();
        for(int i = 0, n = colliding_cb.size(); i<n ; i++){
            if(typeid(Wall1)==typeid(*(colliding_cb[i]))){
                    setPos(X_Prev,Y_Prev);
                    return;
            }
        }

}




void Cowboy::needHorse(){
    setPixmap(QPixmap(":/img/cowboyHorse.png"));
}

int Cowboy::Increaserespect()
{
    return this->respect++;
}

int Cowboy::DecreaseRespecct()
{
    return this->respect--;
}

int Cowboy::getRespect()
{
    return this->respect;
}

void Cowboy::gotHorse()
{
      ownHorse = true;
}


void Cowboy::leaveHorse(){
    ownHorse = false;
}

bool Cowboy::getOwnHorse()
{
    return this->ownHorse;
}

void Cowboy::SetWalkedOnHedgehog()
{
    WalkedOnHedgehog = true;
}

bool Cowboy::getWalkedOnHedgehog()
{
    return this->WalkedOnHedgehog;
}

void Cowboy::setVitesse()
{
    vitesse = 50;
}

int Cowboy::getVitesse()
{
    return this->vitesse;
}

void Cowboy::spawn()
{
    //on créer un brigand
    Brigand * bg = new Brigand();
    scene()->addItem(bg);

}

void Cowboy::spawnDame()
{
        Dame * dame = new Dame();
        scene()->addItem(dame);
}

void Cowboy::spawnHedgehog()
{
    //on créer un hérisson
   Hedgehog * hed = new Hedgehog();
     scene()->addItem(hed);
}

void Cowboy::spawnHorse()
{
    Score * score = new Score();

     if(score->getScore() == 0){
    // on créer le cheval
    Horse * horse = new Horse();
    scene()->addItem(horse);
}
}


