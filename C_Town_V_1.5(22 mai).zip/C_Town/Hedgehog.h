#ifndef HEDGEHOG_H
#define HEDGEHOG_H

#include <QGraphicsPixmapItem>
#include <QGraphicsRectItem>
#include <QObject>
#include <QGraphicsItem>

class Hedgehog: public QObject , public QGraphicsPixmapItem{
     Q_OBJECT
    public :
     int Rand(int a, int b);
     Hedgehog(QGraphicsItem * parent = 0);
 public slots:
     void onScene();
 };





#endif // HEDGEHOG_H
